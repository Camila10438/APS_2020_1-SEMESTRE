Para ativar sua fonte dentro do css para utilizar em sua página siga as seguintes instruções:

1. Verifique se a extensão da fonte é do tipo .otf ou .ttf (padrão usado pela maiorias dos navegadores)
se não for apenas a converta para um dos dois padrões

2. Crie uma pasta com o nome da sua font
  2.1 Caso você não tenha baixado a fonte siga o passo 3.1

3. Insira o seguinte trecho de código dentro de @font-face:
font-family: Roboto-Regular;
	src: url('fonts/Roboto/otf/Roboto-Regular.otf');

  3.1 Insira o seguinte trecho de código:
	@import url('https://fonts.googleapis.com/css2?family=Comic+Neue:wght@300&display=swap');
	obs: não se esqueça de dizer como usar a fonte quando ela for importada via servidor ex:
	/*Para usar a fonte acima adicione o seguinte código:font-family: 'Comic Neue', cursive*/

obs: substitua Roboto-Regular pelo nome da sua fonte e a url dentro de onde ela se localiza