document.getElementsByClassName('lixou').onclick = function() {shw()};
function shw() {
  document.getElementById('iframe-lixo').style.display = "block";
}
